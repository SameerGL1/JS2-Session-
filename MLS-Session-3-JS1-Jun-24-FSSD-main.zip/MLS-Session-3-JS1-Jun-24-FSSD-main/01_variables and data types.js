// 1. Declare a variable called `personName` and assign your name to it.
var personName = "Sameer"; 
console.log(personName); 

// 2. Create a variable `age` and assign your age to it.
var age = 25;
console.log(age);

// 3. Create a variable `isStudent` and assign it a boolean value.
var isStudent = true;
console.log(isStudent);

// 4. Declare a variable `isSingleDigit` and assign it a boolean value based on the value of the given number, `num` if its less than 10

// 5. Create a variable `myNullValue` and assign it a null value.

// 6. Create a variable `undefinedVariable` and without assigning any value to it, display its value.

// 7. Declare a variable `yearsInCollege` and assign it a numeric value. Then, create a new variable `isInCollege` and assign it a boolean value based on whether `yearsInCollege` is greater than zero.
